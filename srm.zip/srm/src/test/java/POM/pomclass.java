package POM;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class pomclass
{
	WebDriver driver;
	   @FindBy(how = How.XPATH,using="//*[@id=\"fname\"]") 
	   public static WebElement firstname;
	  
	   @FindBy(how = How.XPATH,using="//*[@id='lname']") 
	   WebElement lastname;
	   /**
	   @FindBy(how = How.XPATH,using="//*[@id='submitBtn']") 
	   WebElement loginbutton;
	   @FindBy(how = How.LINK_TEXT,using="Logout") 
	   WebElement logoutelement;
	   */
	   public pomclass(WebDriver driver)
	   {
	       this.driver = driver;
	        PageFactory.initElements(driver, this);
	      // driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
	   }
	    
	     public void firstname(String n)
	     {
	         
	    	 //System.out.println(enquiry.getAttribute("cols"));
	    	 
	    	 firstname.sendKeys(n);
	     }
	     
	     public void lastname(String pass)
	     {
	         lastname.sendKeys(pass);
	     }
	     /**
	     public void clickloginbutton()
	     {
	    	 loginbutton.click();
	     }
	     public boolean checkforlogout()
	     {
	    	 boolean a=logoutelement.isDisplayed();
	    	 return a;
	     }
	    */ 
	   
   
}
