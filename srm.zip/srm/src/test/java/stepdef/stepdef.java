package stepdef;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import POM.pomclass;
import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;		
import cucumber.api.java.en.Then;		
import cucumber.api.java.en.When;		
public class stepdef 
{				
 	WebDriver d ;
  	pomclass pom;
    @Given("^Open coaching page$")				
    public void Open() throws Throwable							
    {	
    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\chromedriver.exe");
    	  d=new ChromeDriver();
 
        d.get("file:C:\\Coaching_Class_Enquiry.html");
        d.manage().window().maximize();
        
       
    }		
    
 @Then("^verify title and text$")					
    public void check() throws Throwable 							
    {    		
	// Thread.sleep(10000);
     //System.out.println("Title is correct-No defect");

	 
	 String a=d.getTitle();
	    if(a.equalsIgnoreCase("online coaching class enquiry form")) 
	    {
	        System.out.println("Title is correct-No defect");

	    }
	    else
	    {
	        System.out.println("Title is not correct-A defect");
	    }
    	 boolean aq=d.getPageSource().contains("Your");
		    if(aq) 
		    {
		        System.out.println("Text is present-No defect");

		    }
		    else
		    {
		        System.out.println("Text is not present-A defect");
		    }
		    //d.close();
	      //throw new PendingException();
       }		
 
 @When("^enter last name and firstname blank than$")					
 public void entername() throws Throwable 							
 {    		
	 //Thread.sleep(10000);
     pom=new pomclass(d);
	 pom.firstname("");

	 pom.lastname("husain");
	      //throw new PendingException();

	 }		
 
 @Then("^alert message for entering comes$")					
 public void checkalert() throws Throwable 							
 {    		
	  try
	  {
		  String t=d.switchTo().alert().getText();
		  System.out.println(t);

		  if(t.equalsIgnoreCase("First Name must be filled out"))
		  {
			  System.out.println("on not entering first name and entering in next box alert with text appeared-No defect");
		  }
		  else
		  {
			  System.out.println("on not entering first name and entering in next box alert with text did not appeared-A defect");

		  }
	  }
	  catch(Exception e)
	  {
		  System.out.println("alert did not appear");
	  }
	 //d.close();
    //throw new PendingException();
 	 }		
 
 @After
 void close()
 {
	 d.close();
 }
 


}