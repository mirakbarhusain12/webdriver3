package MainPackage;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class POMTestcaseFactory
{
	public static void main(String[] args) 
	{
		WebDriver driver = null;
 		System.setProperty("webdriver.chrome.driver","C:\\Users\\\\Admin\\Downloads\\chromedriver.exe");
 		driver = new ChromeDriver();
       	POMPagefactory pomobject = new POMPagefactory(driver);
 		driver.get("http:\\www.google.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		pomobject.Enteritem("train");
		//WebElement e1=pomobject.editboxinput;
		//pomobject.clicklink();
	}

}
