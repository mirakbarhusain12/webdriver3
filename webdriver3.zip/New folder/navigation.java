package MainPackage;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;

public class navigation 
{

	public static void main(String[] args) throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Admin\\Downloads\\chromedriver.exe");
  		WebDriver driver=new ChromeDriver();
		
  		driver.get("https:\\www.jetairways.com");
  		
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        driver.manage().window().maximize();
       //WebElement e2=driver.findElement(By.cssSelector("#headerDropDowns li:nth-of-type[2]"));
      driver.findElement(By.cssSelector("ul[id='headerDropDowns'] li:nth-of-type(2)>a")).click();
     // Thread.sleep(15000);
      WebElement e1=driver.findElement(By.cssSelector("ul[class='sub-menu'] li:nth-child(6)>a"));
      Actions a=new Actions(driver);
      a.moveToElement(e1).click().build().perform();
     // driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
      driver.findElement(By.cssSelector("ul[id='headerDropDowns'] li:nth-of-type(2)>a")).click();
      Thread.sleep(10000);
       driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);

      WebElement e2=driver.findElement(By.cssSelector("ul[class='sub-menu'] li:nth-child(1)>a"));
      Thread.sleep(25000);

      a.moveToElement(e2).click().build().perform();
      Set<String> s=driver.getWindowHandles();
      int size=s.size();
		System.out.println("Total number of windows opened="+""+size);

		for(String h:s)
		{
			driver.switchTo().window(h);
			String t=driver.getTitle();
			System.out.println(t);
			
		}	
		driver.navigate().back();
		System.out.println(driver.getTitle());
		driver.navigate().back();
		System.out.println(driver.getTitle());
		
		driver.navigate().forward();
		System.out.println(driver.getTitle());
		driver.navigate().forward();
		System.out.println(driver.getTitle());
		driver.navigate().to("http:\\www.spicejet.com");
		 
      
      // e2.click();
       
       //driver.findElement(By.cssSelector("ul[class='a-nostyle a-list-link'] li:nth-child(12)>a")).click();


	}

}
