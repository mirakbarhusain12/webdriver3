package MainPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class javascriptexecutor2
{
	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.rbs.com");
		driver.manage().window().maximize();
	     // WebElement e1 = driver.findElement(By.id("onlineId1"));

	      
//((JavascriptExecutor) driver).executeAsyncScript("window.setTimeout(arguments[arguments.length - 1], 500);");
	    //	   System.out.println("Elapsed time: " + (System.currentTimeMillis() - start));  
	      
	      
	      
	  //driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
        //WebElement e1=driver.findElement(By.xpath("//span[@class='headerAuth__notAuthenticated']"));
		JavascriptExecutor js = (JavascriptExecutor)driver;  
        //js.executeScript("document.getElementById('onlineId1').value='12';");
     // WebElement t1= (WebElement) js.executeScript("document.getElementById('onlineId1');");
       /// js.executeScript("arguments[0].value='12';",e1);
     // js.executeScript("arguments[1].value='12';",e1);
     // driver.manage().timeouts().pageLoadTimeout(20,TimeUnit.SECONDS);
     //js.executeScript("window.scrollBy(0,1000)");
       // driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement e2 = driver.findElement(By.linkText("View all news and opinion"));

     //This will scroll the page till the element is found		
        js.executeScript("arguments[0].scrollIntoView(true);",e2);
 
        
       

	}

}
