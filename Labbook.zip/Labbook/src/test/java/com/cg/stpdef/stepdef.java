package com.cg.stpdef;


import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.cg.pom.Pomclass;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;		
public class stepdef 
{				
 	WebDriver d ;
 	
  	Pomclass pom;
  	Pomclass pom1;
  	Pomclass pom2;
 @Before
 public void bs()
 {
	 System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\chromedriver.exe");
 	  d=new ChromeDriver();
	//System.setProperty("webdriver.gecko.driver","d:\\geckodriver.exe");
	 //d=new FirefoxDriver();
 }
  	
 @Given("^Equipment entry is already in the system as Purchase phase is over\\.$")
 public void equipment_entry_is_already_in_the_system_as_Purchase_phase_is_over() throws Throwable 
 {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Given("^Equipment ?Use status? can be ?In Use? if it is installed and assigned to some user/Department or it can be ?In stock? if it is not put in Use\\.$")
 public void equipment_Use_status_can_be_In_Use_if_it_is_installed_and_assigned_to_some_user_Department_or_it_can_be_In_stock_if_it_is_not_put_in_Use() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Given("^Authorized users and systems update equipment records\\.$")
 public void authorized_users_and_systems_update_equipment_records() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^The system must enforce requirements of the equipment Type properties while updation$")
 public void the_system_must_enforce_requirements_of_the_equipment_Type_properties_while_updation() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^Only valid Locations can be assigned to an equipment record when completing an update transaction\\.  End Date has not expired$")
 public void only_valid_Locations_can_be_assigned_to_an_equipment_record_when_completing_an_update_transaction_End_Date_has_not_expired() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^Only valid Users can be assigned to an equipment record when completing an update     transaction\\.  End Date has not expired$")
 public void only_valid_Users_can_be_assigned_to_an_equipment_record_when_completing_an_update_transaction_End_Date_has_not_expired() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Given("^Users update equipment records\\.$")
 public void users_update_equipment_records() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^The authorized users like Inventory personnel, equipment auditors, service personnel, maintenance personal and Equipment Tracking personnel can only update$")
 public void the_authorized_users_like_Inventory_personnel_equipment_auditors_service_personnel_maintenance_personal_and_Equipment_Tracking_personnel_can_only_update() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Given("^Users inputs  \"([^\"]*)\" less than (\\d+) charectors$")
 public void users_inputs_less_than_charectors1(String arg1, int arg2) throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^user should see a message for entering (\\d+) charectors$")
 public void user_should_see_a_message_for_entering_charectors(int arg1) throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Given("^Users inputs  \"([^\"]*)\" Non numeric$")
 public void users_inputs_Non_numeric(String arg1) throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^user should see a message for entering Numeric charectors$")
 public void user_should_see_a_message_for_entering_Numeric_charectors() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Given("^Users inputs  \"([^\"]*)\"$")
 public void users_inputs(String arg1) throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^any blanks or dashes removed automatically$")
 public void any_blanks_or_dashes_removed_automatically() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Given("^Users inputs  \"([^\"]*)\"  in position (\\d+) and (\\d+)$")
 public void users_inputs_in_position_and(String arg1, int arg2, int arg3) throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^text AD removed automatically$")
 public void text_AD_removed_automatically() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Given("^Users inputs  \"([^\"]*)\"  less than(\\d+) charectors$")
 public void users_inputs_less_than_charectors(String arg1, int arg2) throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^leading zeros padded  automatically$")
 public void leading_zeros_padded_automatically() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Given("^Users selects equipments by sequence number$")
 public void users_selects_equipments_by_sequence_number() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^The system must manipulate the Seq number input for query and storage Consistency$")
 public void the_system_must_manipulate_the_Seq_number_input_for_query_and_storage_Consistency() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^The system must use the most recent rules contained within the authorized document$")
 public void the_system_must_use_the_most_recent_rules_contained_within_the_authorized_document() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Given("^user query for an equipment by \"([^\"]*)\"$")
 public void user_query_for_an_equipment_by(String arg1) throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^respective results should be displayed$")
 public void respective_results_should_be_displayed() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Given("^user selects view in equipment tag$")
 public void user_selects_view_in_equipment_tag() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Given("^user selects quality in equipment tag$")
 public void user_selects_quality_in_equipment_tag() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Given("^user selects sequence number in equipment tag$")
 public void user_selects_sequence_number_in_equipment_tag() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Given("^user selects user id in equipment tag$")
 public void user_selects_user_id_in_equipment_tag() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Given("^user selects location in equipment tag$")
 public void user_selects_location_in_equipment_tag() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Given("^user selects equipment type in equipment tag$")
 public void user_selects_equipment_type_in_equipment_tag() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Given("^user update specified data for a single equipment record\\.$")
 public void user_update_specified_data_for_a_single_equipment_record() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^user should should be able to update only in within their state$")
 public void user_should_should_be_able_to_update_only_in_within_their_state() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^Only comments can be updated for retired equipments$")
 public void only_comments_can_be_updated_for_retired_equipments() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^Any Unassociated equipments identified as \"([^\"]*)\" must be ?In Stock?$")
 public void any_Unassociated_equipments_identified_as_must_be_In_Stock(String arg1) throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^Purchase Method ? Required$")
 public void purchase_Method_Required() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^Seq Number - Required based on the equipment type\\.$")
 public void seq_Number_Required_based_on_the_equipment_type() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^User ID  - If allocated to user$")
 public void user_ID_If_allocated_to_user() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^Department ID  - If allocated to department$")
 public void department_ID_If_allocated_to_department() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^Use Status ? Required\\. If stock equipment then default to In-Stock$")
 public void use_Status_Required_If_stock_equipment_then_default_to_In_Stock() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^Cost Center ?Required\\. If Use status is  In-Stock default with Stock Location?s cost center ID$")
 public void cost_Center_Required_If_Use_status_is_In_Stock_default_with_Stock_Location_s_cost_center_ID() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^Location- Required$")
 public void location_Required() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^Audit Indicator \\(Yes/No\\)$")
 public void audit_Indicator_Yes_No() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^Audit Date - Default the Audit Date to the Receipt Date$")
 public void audit_Date_Default_the_Audit_Date_to_the_Receipt_Date() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^comments$")
 public void comments() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^Stock Location - Required if use status is  In-Stock$")
 public void stock_Location_Required_if_use_status_is_In_Stock() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Given("^user prints the equipment?s basic information using ?Print Label? functionality\\.$")
 public void user_prints_the_equipment_s_basic_information_using_Print_Label_functionality() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^Label should include Equipment code$")
 public void label_should_include_Equipment_code() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^Label should include  User ID$")
 public void label_should_include_User_ID() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^Label should include Location ID$")
 public void label_should_include_Location_ID() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Given("^user update specified data in an equipment record from external systems\\.$")
 public void user_update_specified_data_in_an_equipment_record_from_external_systems() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^System should receive automatic updates from the ?CompTrak? system for  Computer Name Disk Capacity Total installed memory Network Card number Network Card Manufacturer Free space on ?C? Drive Operating system OS version$")
 public void system_should_receive_automatic_updates_from_the_CompTrak_system_for_Computer_Name_Disk_Capacity_Total_installed_memory_Network_Card_number_Network_Card_Manufacturer_Free_space_on_C_Drive_Operating_system_OS_version() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @When("^The equipment tag is not found in ?Equipment tracking system and Last scan date for a stored in the ?Equipment tracking system? is greater than the ?Last Scan date? stored in the ?CompTrak? system$")
 public void the_equipment_tag_is_not_found_in_Equipment_tracking_system_and_Last_scan_date_for_a_stored_in_the_Equipment_tracking_system_is_greater_than_the_Last_Scan_date_stored_in_the_CompTrak_system() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }

 @Then("^Errors would be generated$")
 public void errors_would_be_generated() throws Throwable {
     // Write code here that turns the phrase above into concrete actions
     throw new PendingException();
 }



 /**
 @After
 public void afterScenario1()
 {
   
   d.close();
 }
*/
}

