package com.cg.runner;
import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
@RunWith(Cucumber.class)
@CucumberOptions(
		features={"src\\test\\java\\com\\cg\\feature"}
		,glue= {"src\\test\\java\\com.cg.stpdef\\stepdef.java"}
		//features="com.cg.feature",glue= {"com.cg.stepdef"}
		,plugin = {"pretty", "html:target/husain-report"}
		,monochrome=true
		,tags= {"@sanity1"}		
		,dryRun=true
		,strict=true
		)
public class r
{    

}

 
