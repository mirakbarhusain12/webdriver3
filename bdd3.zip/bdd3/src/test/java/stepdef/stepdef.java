package stepdef;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import POM.pomclass;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;		
import cucumber.api.java.en.Then;		
import cucumber.api.java.en.When;		
public class stepdef 
{				
 	WebDriver d ;
  	pomclass pom=new pomclass(d);

    @Given("^Open ksrtc web site$")				
    public void Open_ksrtc_web_site() throws Throwable							
    {	
    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\chromedriver.exe");
    	  d=new ChromeDriver();
        d.get("http://www.ksrtc.in/oprs-web/");
        d.manage().window().maximize();
        
     }		
    @When("^user input name \\\"(.*)\\\"$")
    public void userinputsusername(String name) throws Throwable 							
    {		
        pom.clicksign();
    	Thread.sleep(2000);
        pom.entername(name);  	    //throw new PendingException();
    }		
    @And("^user input password \\\"(.*)\\\"$")
    public void userinputPassword(String password) throws Throwable 							
    {		
    	pom.enterpassword(password);
        //throw new PendingException();
    }		
 @Then("^Login should be successfull$")					
    public void Login_should_be_successfull() throws Throwable 							
    {    		
    	 boolean a=pom.checkforlogout();
		    if(a) 
		    {
		        System.out.println("login success for valid name  and valid password No defect");

		    }
		    else
		    {
		        System.out.println("login not success for valid name  and valid password A defect");
		    }
	      //throw new PendingException();

	 }		

}