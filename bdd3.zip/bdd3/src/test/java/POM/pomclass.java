package POM;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class pomclass
{

	
	WebDriver driver;
   @FindBy(how = How.LINK_TEXT,using="Sign In") 
   WebElement sign;
   @FindBy(how = How.XPATH,using="//*[@id='userName']") 
   WebElement name;
   @FindBy(how = How.XPATH,using="//*[@id='password']") 
   WebElement password;
   @FindBy(how = How.XPATH,using="//*[@id='submitBtn']") 
   WebElement loginbutton;
   @FindBy(how = How.LINK_TEXT,using="Logout") 
   WebElement logoutelement;
   
   public pomclass(WebDriver driver)
    {
        this.driver = driver;
         PageFactory.initElements(driver, this);
        driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
    }
     public void clicksign()
    {
        sign.click();
    }
     public void entername(String name1)
     {
         name.sendKeys(name1);
     }
     public void enterpassword(String pass)
     {
         password.sendKeys(pass);
     }
     public void clickloginbutton()
     {
    	 loginbutton.click();
     }
     public boolean checkforlogout()
     {
    	 boolean a=logoutelement.isDisplayed();
    	 return a;
     }
     
   
}
